# Credits - `yourdonation.rocks`

- [Core Developer](nikolaskama.me) - [Nikolaos Kamarinakis](mailto:nikolaskam@gmail.com) (k4m4)

- [Image 3 (edited)](thenounproject.com) - by Luis Rodrigues
- [Image 6 (edited)](thenounproject.com) - by Maxim David

- [Bootstrap (CCA 3.0 license)](http://html5up.net)